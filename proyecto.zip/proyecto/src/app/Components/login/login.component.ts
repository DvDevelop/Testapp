import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../../app.component';
import { AngularFireDatabase,} from "@angular/fire/database";
import { AngularFireAuth } from "@angular/fire/auth";
import { auth } from "firebase/app";
import { Router } from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private _Appcomponent: AppComponent,public afAuth: AngularFireAuth) {
    this._Appcomponent.setTitle('Papeleria EBL Log In');
    //this.afAuth.auth.createUserWithEmailAndPassword(email,pass).catch(function(error){});
   }

  ngOnInit() {
  }

}
