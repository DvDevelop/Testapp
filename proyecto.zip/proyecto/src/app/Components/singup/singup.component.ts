import { Component, OnInit } from '@angular/core';
import { AppComponent } from '../../app.component';
import { FormControl,FormGroup,Validator, Validators } from "@angular/forms";
import { AngularFireDatabase,} from "@angular/fire/database";
import { AngularFireAuth } from "@angular/fire/auth";
import { auth } from "firebase/app";

@Component({
  selector: 'app-singup',
  templateUrl: './singup.component.html',
  styleUrls: ['./singup.component.css']
})
export class SingupComponent implements OnInit {
  logform: FormGroup;
  constructor(private _Appcomponent: AppComponent,private afAuth: AngularFireAuth) { 
    this._Appcomponent.setTitle('Papeleria EBL Sing Up');
    this.logform = new FormGroup({
      username: new FormControl('',[Validators.required, Validators.minLength(3)]),
      usermail: new FormControl('',[Validators.required, Validators.email]),
      password: new FormControl('',[Validators.required, Validators.minLength(8)]),
      secpass: new FormControl('',[Validators.required, Validators.minLength(8)])
    });
  }

  ngOnInit() {
  }
  
  check(){
    if(this.logform.get('password') == this.logform.get('secpass')){
      console.log("contraceñas iguales");
    }else{
      console.log(this.logform.value);
    }
  }
}
